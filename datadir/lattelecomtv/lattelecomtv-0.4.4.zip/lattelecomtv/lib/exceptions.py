class ApiError(Exception):
    pass